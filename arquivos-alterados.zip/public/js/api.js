
// Modo de demonstração: liga automaticamente quando o site é aberto como
// arquivo local (sem servidor) ou quando o usuário força com ?mock=1.
// Nesse modo nada é enviado para fora do navegador.
const params = new URLSearchParams(location.search);
if (params.get('mock') === '1') localStorage.setItem('cip_force_mock', '1');
if (params.get('mock') === '0') localStorage.removeItem('cip_force_mock');

export const MODO_DEMO = location.protocol === 'file:' || localStorage.getItem('cip_force_mock') === '1';

async function chamar(action, payload) {
  if (MODO_DEMO) {
    if (action === 'login') {
      return payload && payload.senha ? { ok: true, papel: 'admin', nome: 'Administrador' } : { ok: false, error: 'Digite uma senha.' };
    }
    if (action === 'logout') {
      return { ok: true };
    }
    try {
      const { mockCall } = await import('./mockData.js');
      return { ok: true, data: mockCall(action, payload) };
    } catch (err) {
      return { ok: false, error: err.message };
    }
  }
  const resposta = await fetch('/api', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, payload })
  });
  const dados = await resposta.json().catch(() => ({ ok: false, error: 'Resposta inválida do servidor.' }));
  // 401 no login é só "senha errada" — não uma sessão expirando. Só trata como
  // sessão expirada quando é uma ação autenticada de verdade.
  if (resposta.status === 401 && action !== 'login') {
    window.dispatchEvent(new CustomEvent('sessao-expirada'));
  }
  return dados;
}

async function chamarOuFalhar(action, payload) {
  const r = await chamar(action, payload);
  if (!r.ok) throw new Error(r.error || 'Erro desconhecido.');
  return r.data;
}

// Cache curto de leituras: cada chamada vai Netlify -> Apps Script -> Sheets e
// leva segundos. Leituras iguais dentro de CACHE_MS reaproveitam a mesma
// resposta (inclusive a que ainda está em andamento). Qualquer escrita limpa o
// cache inteiro, então o que este usuário grava aparece na hora.
const CACHE_MS = 30000;
const cacheLeituras = new Map();
const copiar = (d) => (d == null || typeof d !== 'object' ? d : structuredClone(d));

function ler(action, payload) {
  const chave = action + '|' + JSON.stringify(payload ?? null);
  const agora = Date.now();
  const guardado = cacheLeituras.get(chave);
  // Cada tela recebe a sua cópia, para uma não alterar os dados da outra.
  if (guardado && agora - guardado.em < CACHE_MS) return guardado.promessa.then(copiar);
  const promessa = chamarOuFalhar(action, payload);
  cacheLeituras.set(chave, { em: agora, promessa });
  promessa.catch(() => cacheLeituras.delete(chave));
  return promessa.then(copiar);
}

function escrever(action, payload) {
  cacheLeituras.clear();
  return chamarOuFalhar(action, payload).finally(() => cacheLeituras.clear());
}

async function chamarAssistente(corpo) {
  // O assistente pode gravar na planilha (após confirmação): não reaproveitar leituras antigas.
  cacheLeituras.clear();
  if (MODO_DEMO) {
    const mensagens = Array.isArray(corpo.mensagens) ? corpo.mensagens.slice() : [];
    mensagens.push({
      role: 'assistant',
      content: [{ type: 'text', text: 'O assistente de IA só funciona com o backend real configurado (variável GEMINI_API_KEY no Netlify). Em modo de demonstração não há IA disponível — veja o README para configurar.' }]
    });
    return { ok: true, mensagens, pendente: null };
  }
  const resposta = await fetch('/assistente', {
    method: 'POST',
    credentials: 'same-origin',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(corpo)
  });
  const dados = await resposta.json().catch(() => ({ ok: false, error: 'Resposta inválida do servidor.' }));
  if (resposta.status === 401) window.dispatchEvent(new CustomEvent('sessao-expirada'));
  return dados;
}

export const api = {
  login: (senha) => chamar('login', { senha }),
  logout: () => { cacheLeituras.clear(); return chamar('logout', {}); },

  listItens: () => ler('listItens'),
  getItem: (id) => ler('getItem', { id }),
  listEquipamentos: () => ler('listEquipamentos'),
  getEquipamento: (id) => ler('getEquipamento', { id }),
  listVeiculos: () => ler('listVeiculos'),
  getVeiculo: (id) => ler('getVeiculo', { id }),
  listMovimentacoes: (itemId) => ler('listMovimentacoes', { itemId }),
  listColaboradores: () => ler('listColaboradores'),
  listProjetos: () => ler('listProjetos'),
  custoPorProjeto: (projeto) => ler('custoPorProjeto', { projeto }),
  listMateriaisReferencia: () => ler('listMateriaisReferencia'),
  avisos: (dias) => ler('avisos', { dias }),

  criarItem: (payload) => escrever('criarItem', payload),
  registrarEntrada: (payload) => escrever('registrarEntrada', payload),
  alocarColaborador: (payload) => escrever('alocarColaborador', payload),
  registrarSaidaProjeto: (payload) => escrever('registrarSaidaProjeto', payload),
  registrarDevolucao: (payload) => escrever('registrarDevolucao', payload),
  criarEquipamento: (payload) => escrever('criarEquipamento', payload),
  editarEquipamento: (payload) => escrever('editarEquipamento', payload),
  registrarLocacao: (payload) => escrever('registrarLocacao', payload),
  registrarDevolucaoEquipamento: (payload) => escrever('registrarDevolucaoEquipamento', payload),
  registrarCalibracaoEquipamento: (payload) => escrever('registrarCalibracaoEquipamento', payload),
  criarVeiculo: (payload) => escrever('criarVeiculo', payload),
  criarColaborador: (payload) => escrever('criarColaborador', payload),
  criarProjeto: (payload) => escrever('criarProjeto', payload),
  criarMaterialReferencia: (payload) => escrever('criarMaterialReferencia', payload),
  atualizarResponsavelMaterialReferencia: (payload) => escrever('atualizarResponsavelMaterialReferencia', payload),
  editarMaterialReferencia: (payload) => escrever('editarMaterialReferencia', payload),
  duplicarMaterialReferencia: (payload) => escrever('duplicarMaterialReferencia', payload),
  removerMaterialReferencia: (payload) => escrever('removerMaterialReferencia', payload),
  atualizarContratoVeiculo: (payload) => escrever('atualizarContratoVeiculo', payload),

  assistente: (corpo) => chamarAssistente(corpo)
};
