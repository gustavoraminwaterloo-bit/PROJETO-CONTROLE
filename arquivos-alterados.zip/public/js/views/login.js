import { api, MODO_DEMO } from '../api.js';
import { marcarLogado } from '../app.js';
import { icons } from '../icons.js';

export async function viewLogin(main) {
  main.innerHTML = `
    <div class="login-shell">
      <div class="login-box">
        <div class="logo-marca">${icons.logo}</div>
        <h2>Controle de Insumos e Patrimônio</h2>
        <p class="subtitulo" style="color:var(--text-secondary); margin-bottom:20px">Entre para acessar o painel</p>
        <div class="card">
          ${MODO_DEMO ? '<p class="ajuda" style="margin-bottom:12px">Modo de demonstração: digite qualquer senha para entrar.</p>' : ''}
          <form id="form-login">
            <label>Senha
              <input type="password" name="senha" required autofocus placeholder="••••••••" />
            </label>
            <p class="msg-erro" id="erro-login" style="display:none"></p>
            <button type="submit">Entrar</button>
          </form>
        </div>
      </div>
    </div>
  `;

  document.getElementById('form-login').addEventListener('submit', async (e) => {
    e.preventDefault();
    const dados = Object.fromEntries(new FormData(e.target).entries());
    // .trim() porque senha colada costuma vir com espaço/quebra de linha grudado,
    // o que derrubava o login mesmo com a senha certa.
    const senha = (dados.senha || '').trim();
    const erroEl = document.getElementById('erro-login');
    erroEl.style.display = 'none';
    const resp = await api.login(senha);
    if (resp.ok) {
      marcarLogado(true, resp.nome);
      location.hash = '#/';
    } else {
      erroEl.textContent = resp.error || 'Não foi possível entrar.';
      erroEl.style.display = 'block';
    }
  });
}
